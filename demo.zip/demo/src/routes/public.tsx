import { lazy } from 'react'
import { Navigate } from 'react-router-dom'

const Home = lazy(() => import('../views/home'))
const SecondPage = lazy(() => import('../views/secondPage'))

const protectedRoutes = [
	{
		path: '/',
		element: <Home />,
	},
	{
		path: '/secondPage',
		element: <SecondPage />,
	},
	{
		path: '*',
		element: <Navigate to='.' />,
	},
]
export default protectedRoutes
