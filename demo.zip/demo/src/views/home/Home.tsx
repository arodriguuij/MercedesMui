import { Button, Box } from '@mui/material'
import Typography from '@mui/material/Typography'
import { useNavigate } from 'react-router-dom'

const Home = () => {
	const navigate = useNavigate()

	const handleClick = () => {
		navigate('/secondPage')
	}

	return (
		<Box>
			<Typography>Home</Typography>
			<Button variant='contained' onClick={handleClick}>
				Go to SecondPage
			</Button>
		</Box>
	)
}

export default Home
