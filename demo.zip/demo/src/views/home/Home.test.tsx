import { fireEvent, render, screen } from '@testing-library/react'
import { createMemoryHistory } from 'history'
import { BrowserRouter } from 'react-router-dom'
import Home from './Home'

describe('Home', () => {
	it('render a title', () => {
		render(
			<BrowserRouter>
				<Home />
			</BrowserRouter>
		)
		const linkElement = screen.getByText(/Home/i)
		expect(linkElement).toBeInTheDocument()
	})

	it('render a button', () => {
		const history = createMemoryHistory({ initialEntries: ['/'] })
		const { getByText } = render(
			<BrowserRouter>
				<Home />
			</BrowserRouter>
		)
		expect(history.location.pathname).toBe('/')
		const button = getByText('Go to SecondPage')
		fireEvent.click(button)
		expect(history.location.pathname).toBe('/')
	})
})
