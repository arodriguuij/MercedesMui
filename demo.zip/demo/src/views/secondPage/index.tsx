import SecondPage from './SecondPage'

export default SecondPage
