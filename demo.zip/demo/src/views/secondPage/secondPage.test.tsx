import { fireEvent, render, screen } from '@testing-library/react'
import { createMemoryHistory } from 'history'
import { BrowserRouter } from 'react-router-dom'
import SecondPage from './SecondPage'

describe('SecondPage', () => {
	it('render a title', () => {
		render(
			<BrowserRouter>
				<SecondPage />
			</BrowserRouter>
		)
		const linkElement = screen.getByText(/Second Page/i)
		expect(linkElement).toBeInTheDocument()
	})

	it('render a button', () => {
		const history = createMemoryHistory({ initialEntries: ['/secondPage'] })
		const { getByText } = render(
			<BrowserRouter>
				<SecondPage />
			</BrowserRouter>
		)
		expect(history.location.pathname).toBe('/secondPage')
		fireEvent.click(getByText('Home'))
		expect(history.location.pathname).toBe('/secondPage')
	})
})
