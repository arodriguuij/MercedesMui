import { Box, Button } from '@mui/material'
import Typography from '@mui/material/Typography'
import { useNavigate } from 'react-router-dom'

const SecondPage = () => {
	const navigate = useNavigate()

	const handleClick = () => {
		navigate('/')
	}

	return (
		<Box>
			<Typography>Second Page</Typography>
			<Button variant='contained' onClick={handleClick}>
				Home
			</Button>
		</Box>
	)
}

export default SecondPage
